insert into CART(id) values (1);
insert into CART(id) values (2);
insert into CART(id) values (3);


insert into CART_ITEM(id, quantity, price, name, CART_ID) values (1, 10, 5,'Spodnie', 1);
insert into CART_ITEM(id, quantity, price, name, CART_ID) values (2, 20, 56,'Cola', 1);
insert into CART_ITEM(id, quantity, price, name, CART_ID) values (3, 2, 5,'Pepsi', 2);
insert into CART_ITEM(id, quantity, price, name, CART_ID) values (4, 2, 55,'Makaron', 2);
insert into CART_ITEM(id, quantity, price, name, CART_ID) values (5, 3, 5,'Czosnek', 3);
insert into CART_ITEM(id, quantity, price, name, CART_ID) values (6, 5, 52,'Czapka', 3);

